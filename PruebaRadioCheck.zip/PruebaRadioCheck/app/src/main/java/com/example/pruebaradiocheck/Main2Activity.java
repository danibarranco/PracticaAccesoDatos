package com.example.pruebaradiocheck;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.sql.SQLOutput;

public class Main2Activity extends AppCompatActivity {
    private Spinner spinner;
    private Button btFin;
    private TextView tvFin;
    private boolean entra= false;
    int precio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        initComponents();
    }

    private void initComponents() {
        spinner=findViewById(R.id.spinner);
        Log.v("xxx",""+getIntent().getIntExtra("a",0));
        ArrayAdapter<CharSequence> adapter =
                ArrayAdapter.createFromResource(this,getIntent().getIntExtra("a",0),R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String producto=spinner.getSelectedItem().toString();
                    try{
                        precio=readPreferences()+Integer.parseInt(producto.split(" ")[1].split("€")[0]);
                        savePreferences(precio);
                        Log.v("xxx","compra "+precio);
                    }catch (NumberFormatException e){
                    }
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });

        btFin= findViewById(R.id.button);
        tvFin=findViewById(R.id.tvFin);
        btFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvFin.setText("El total es: "+precio+"€");
                precio=0;
                savePreferences(precio);
            }
        });
    }
    private int readPreferences() {
        SharedPreferences pc= getPreferences(Context.MODE_PRIVATE);
        return pc.getInt("clavePrecio",0);
    }
    private void savePreferences(int precio){
        SharedPreferences pc;
        SharedPreferences.Editor editor;
        pc= getPreferences(Context.MODE_PRIVATE);
        editor = pc.edit();
        editor.putInt("clavePrecio",precio);
        editor.commit();
    }
}
