package com.example.pruebaradiocheck;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    private RadioGroup radioGroup;
    private String A="a";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
    }

    private void initComponents() {
        radioGroup=findViewById(R.id.radioGroup);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.radioButton:
                        Intent i= new Intent(MainActivity.this,Main2Activity.class);
                        i.putExtra(A,R.array.lacteos);
                        startActivity(i);
                        break;
                    case R.id.radioButton2:
                         i= new Intent(MainActivity.this,Main2Activity.class);
                        i.putExtra(A,R.array.carnes);
                        startActivity(i);
                        break;
                    case R.id.radioButton3:
                         i= new Intent(MainActivity.this,Main2Activity.class);
                        i.putExtra(A,R.array.pescado);
                        startActivity(i);
                        break;
                    case R.id.radioButton4:
                         i= new Intent(MainActivity.this,Main2Activity.class);
                        i.putExtra(A,R.array.verduras);///////////////YJJGJRNRTGNHRT
                        startActivity(i);
                        break;

                }

            }
        });
    }
}
